/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'ca', {
	confirmCleanup: 'El text que voleu enganxar sembla provenir de Word. Voleu netejar aquest text abans que sigui enganxat?',
	error: 'No ha estat possible netejar les dades enganxades degut a un error intern',
	title: 'Enganxa des del Word',
	toolbar: 'Enganxa des del Word'
} );
