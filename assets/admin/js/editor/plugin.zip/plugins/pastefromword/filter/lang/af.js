/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'af', {
	confirmCleanup: 'Die teks wat u wil byvoeg lyk asof dit uit Word gekopiëer is. Wil u dit eers skoonmaak voordat dit bygevoeg word?',
	error: 'Die bygevoegte teks kon nie skoongemaak word nie, weens \'n interne fout',
	title: 'Uit Word byvoeg',
	toolbar: 'Uit Word byvoeg'
} );
