/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'cy', {
	confirmCleanup: 'Mae\'r testun rydych chi am ludo wedi\'i gopïo o Word. Ydych chi am ei lanhau cyn ei ludo?',
	error: 'Doedd dim modd glanhau y data a ludwyd oherwydd gwall mewnol',
	title: 'Gludo o Word',
	toolbar: 'Gludo o Word'
} );
